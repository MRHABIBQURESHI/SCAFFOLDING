﻿using Microsoft.EntityFrameworkCore;
using Scafolding.Models;

namespace Scafolding.Data
{
    public class ScafoldingDbContext : DbContext
    {
        public ScafoldingDbContext(DbContextOptions options) : base(options)
        {
        }
        public DbSet<Employee>? Employees { get; set; }
    }
}
